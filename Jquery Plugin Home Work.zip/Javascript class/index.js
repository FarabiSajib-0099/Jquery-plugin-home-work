

$(document).ready(function(){



$('#btn1').click(function(){
    $('p').hide('slow')


});

$('#btn2').click(function(){
    $('p').show('slow')
});

});



$(document).ready(function(){
$('#btn3').mouseenter(function(){

    $('#text-one').hide(2000)
        
});
$('#btn4').mouseenter(function(){

    $('#text-one').show(2000)
        
});

});

$(document).ready(function(){

$('#btn5').mouseleave(function(){

$('#text-two').hide(2000);
});
$('#btn6').mouseleave(function(){

    $('#text-two').show(2000);
    });

});

$(document).ready(function(){
  $('#btn7').dblclick(function(){

$(this).hide();

  });
  $('#btn8').dblclick(function(){
  $('#btn7').show()
  });

});

/*--------------Slide Section---------*/


$(document).ready(function(){


    $('#slidedown').click(function(){
$('#allcontent').slideToggle('slow');
    });
    $('#slideup').click(function(){

     $('#allcontent').slideUp('slow');

    });

});

/*----animate section---------*/

$(document).ready(function(){


    $('#animate-btn').click(function(){

    var animte =$('#allcontent-animate');
animte.animate({
  "top":"300px",
  "font-size":"30px",
  "width":"300px"

});
    });

});

$(document).ready(function(){

$('h6').parentsUntil().css({
"color":"red",

"font-size":"20px"

});

});

$(document).ready(function(){
$('#dec').children().css({
"color":"#000",
"border":"2px solid #000"

});
$('#dec').find('h1').css({

    "color":"red"
});

});